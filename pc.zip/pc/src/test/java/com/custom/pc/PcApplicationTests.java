package com.custom.pc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcApplicationTests {

	@Test
	void contextLoads() {
	}

}
