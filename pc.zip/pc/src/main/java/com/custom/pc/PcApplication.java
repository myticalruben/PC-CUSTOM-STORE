package com.custom.pc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcApplication.class, args);
	}

}
